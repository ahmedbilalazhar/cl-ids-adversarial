PHASE 3 SUBMISSION
Roll numbers: 23I-2568 and 23I-2581

START HERE
Open 01_FINAL_REPORT/phase3-report.pdf. The editable LaTeX and Markdown sources, figures, tables, and evidence ledgers are alongside it.

FOLDER GUIDE
01_FINAL_REPORT/                 Final report and its supporting evidence and figures.
02_METHODOLOGY_AMENDMENT/        Phase 2 feedback changes and adopted methodology amendments.
03_REPRODUCIBLE_PROJECT/         Complete packaged project snapshot, with original paths preserved for reproducibility.

REQUIREMENT COVERAGE
- Method implementation: source modules and experiment runners in 03_REPRODUCIBLE_PROJECT/src and scripts.
- Dataset and preprocessing: dataset reports, preparation manifests, dataset artifacts, and preprocessing code in the project snapshot.
- Baselines and evaluation: report sections, result tables, metrics, and run records.
- Visual results: publication figures in 01_FINAL_REPORT/figures.
- Existing research comparison: report section and primary-source ledger.
- Ablations: report section, corrected ablation tables, and supporting experiment outputs.
- Analysis and discussion: report discussion, limitations, and reproducibility section.
- Reproduction: project README, experiment configs, code, notebooks, environment files, and protocol documents in the project snapshot.

The full project snapshot is retained under one folder so its internal paths remain intact. The report is also presented at the top level for quick access.